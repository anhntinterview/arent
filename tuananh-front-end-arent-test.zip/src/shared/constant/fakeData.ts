export const chartData = {
    unit: '月',
    list: [
        {
            name: '6',
            teal: 10,
            yellow: 8,
        },
        {
            name: '7',
            teal: 7,
            yellow: 7,
        },
        {
            name: '8',
            teal: 8,
            yellow: 9,
        },
        {
            name: '9',
            teal: 6,
            yellow: 5,
            amt: 7,
        },
        {
            name: '10',
            teal: 7,
            yellow: 7,
            amt: 6,
        },
        {
            name: '11',
            teal: 6,
            yellow: 5,
            amt: 5,
        },
        {
            name: '12',
            teal: 4,
            yellow: 3,
        },
        {
            name: '1',
            teal: 3,
            yellow: 4,
        },
        {
            name: '2',
            teal: 2,
            yellow: 3,
        },
        {
            name: '3',
            teal: 5,
            yellow: 1,
        },
        {
            name: '4',
            teal: 2,
            yellow: 2,
        },
        {
            name: '5',
            teal: 2,
            yellow: 1,
        },
    ],
};
