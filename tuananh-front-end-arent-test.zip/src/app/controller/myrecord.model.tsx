class MyRecordeModel {
    public query() {}
}

export default MyRecordeModel;
