class TopPageModel {
    public query() {}
}

export default TopPageModel;
