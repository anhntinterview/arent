class ColumnPageModel {

    public query() {
        
    }
}

export default ColumnPageModel;
