import { Container, Service } from 'typedi';

@Service()
class TooltipTemplateModel {
}

export default TooltipTemplateModel;
